/*
 *  Homework #1: Variables and Constants
 *  Get Swifty - Part 1
 *  Pirple
 *
 * 
 *
 *  My favorite song
 *  Swift file to describe meta data about the chosen song
 */

let artist: String = "Cut One" // performer
let yearReleased: Int = 2012 // year when the song was released
let genre: String = "Chill out" // music genre
let duration: Int = 177 // 2:57 in seconds
let title: String = "Take Me Home" // song title
let album: String = "Chillwave" // album title
let albumSong: Int = 7 // number of song in album
let isCompilation: Bool = true // the album is a compilation of songs from various artists
let copyright: String = "© 2012 Extreme Music"
let spotifyURL: String = "https://open.spotify.com/track/2JYR24PEKmbM8cYSJPprBp?si=QYU5EvF_Te-WOsZSITjd8g"
let spotifyPlays: Int = 54_121

// song information printed in the console
print(artist)
print(yearReleased)
print(genre)
print(duration)
print(title)
print(album)
print(albumSong)
print(isCompilation)
print(copyright)
print(spotifyURL)
print(spotifyPlays)
